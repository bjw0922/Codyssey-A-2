# 실제 증거 스크린샷

실행한 뒤 직접 캡처한 이미지 파일을 이 폴더에 저장합니다.

권장 파일명:
- 01-environment.png
- 02-permissions.png
- 03-docker-version.png
- 04-hello-world.png
- 05-web-8088.png (주소창 포함)
- 06-web-8081.png (주소창 포함)
- 07-bind-before.png
- 08-bind-after.png
- 09-volume-persistence.png
- 10-vscode-github.png

캡처 전 개인 정보·토큰·인증 코드는 가립니다.
