# 1. Linux 터미널과 권한 실습

## 현재 작업 위치와 명령어

```bash
# 이 칸에 실제 실행한 명령어를 붙여 넣으세요.
```

## 실제 출력 결과

```text
[실행 후 채우기]
```

## 파일 권한 변경 전/후 비교

```text
[실행 후 채우기]
```

## 확인 사항
- [ ] pwd, ls -la, cd
- [ ] mkdir, touch, echo, cat, cp, mv, rm, rmdir
- [ ] chmod 파일 1개, 디렉터리 1개
