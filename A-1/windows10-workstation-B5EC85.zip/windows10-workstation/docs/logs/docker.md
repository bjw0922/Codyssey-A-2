# 2. Docker 설치 확인, 이미지와 컨테이너, 웹 서버

## 명령어

```bash
# 사용한 명령을 기록하세요.
```

## 실제 출력

```text
[실행 후 채우기]
```

## 포트 8088과 8081 응답

```text
[각 포트의 실제 curl 응답을 붙여 넣으세요]
```

## 검사 사항
- [ ] docker --version, docker info, docker images, docker ps -a
- [ ] docker logs, docker stats --no-stream
- [ ] hello-world, Ubuntu, exec/attach
- [ ] Dockerfile 빌드, 웹 서버 실행, HTTP 200
