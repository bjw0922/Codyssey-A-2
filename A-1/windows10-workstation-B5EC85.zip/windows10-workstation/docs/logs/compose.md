# 4. Docker Compose (선택)

## config, up, ps, logs, down

```text
[실행 후 채우기]
```

## inspector → web 서비스 통신 결과

```text
[실행 후 채우기]
```
